/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type File = {
    uuid: string;
    filePath?: string;
    tags: string;
    fileName?: string;
    fileText?: string;
    views?: string;
    userId?: string;
    createdAt?: string;
    updatedAt?: string;
};

