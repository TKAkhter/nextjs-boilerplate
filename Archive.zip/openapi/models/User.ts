/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type User = {
    uuid: string;
    name: string;
    username: string;
    email: string;
    password: string;
    bio?: string;
    phoneNumber?: string;
    createdAt: string;
    updatedAt: string;
};

