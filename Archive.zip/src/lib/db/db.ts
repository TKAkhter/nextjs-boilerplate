import { PrismaClient } from "@prisma/client";

let db: PrismaClient;

db = new PrismaClient();

export default db;





