const ListSocial = {
  Github: {
    name: "Github",
    icon: "github",
    href: "https://github.com/"
  },
  Discord: {
    name: "Discord",
    icon: "discord",
    href: "https://discord.gg/GegRMKrw"
  },
  Linkedin: {
    name: "Linkedin",
    icon: "linkedin",
    href: "/"
  },
  x: {
    name: "Twitter",
    icon: "twitter",
    href: "/"
  }
}

export default ListSocial
