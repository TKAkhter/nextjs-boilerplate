"use client"

export default function GlobalError() {
  return (
    <html>
      <body></body>
    </html>
  )
}
