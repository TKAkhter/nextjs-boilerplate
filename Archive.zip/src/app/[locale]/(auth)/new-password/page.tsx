import { NewPasswordForm } from "@/app/[locale]/(auth)/new-password/_form"

const NewPasswordPage = () => {
  return <NewPasswordForm />
}

export default NewPasswordPage
