import { LoginForm } from "./_form"

export default async function SignInPage() {
  return <LoginForm />
}
