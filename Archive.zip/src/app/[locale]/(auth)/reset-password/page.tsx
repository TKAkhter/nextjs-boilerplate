import { ResetForm } from "@/app/[locale]/(auth)/reset-password/_form"

const ResetPage = () => {
  return <ResetForm />
}

export default ResetPage
