import { ErrorCard } from "@/components/error-card";

const AuthErrorPage = () => {
  return ( 
    <ErrorCard />
  );
};
 
export default AuthErrorPage;
