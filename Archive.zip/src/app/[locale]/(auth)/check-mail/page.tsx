import { NewcheckmailForm } from "@/app/[locale]/(auth)/check-mail/_form"

const NewcheckmailPage = () => {
  return <NewcheckmailForm />
}

export default NewcheckmailPage
