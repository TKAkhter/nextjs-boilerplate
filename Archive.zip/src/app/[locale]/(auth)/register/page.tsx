import { RegisterForm } from "@/app/[locale]/(auth)/register/_form"

const RegisterPage = () => {
  return <RegisterForm />
}

export default RegisterPage
