import { NewVerificationForm } from "@/app/[locale]/(auth)/new-verification/_form"

const NewVerificationPage = () => {
  return <NewVerificationForm />
}

export default NewVerificationPage
