import Features from "@/app/[locale]/(marketing)/resources/features/Features_advanced"

export default function Home() {
  return (
    <>
      <Features />
    </>
  )
}
