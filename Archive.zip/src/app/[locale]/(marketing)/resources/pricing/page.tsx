import Pricing from "@/app/[locale]/(marketing)/resources/pricing/Pricing"

export default function Home() {
  return (
    <>
      <Pricing />
    </>
  )
}
