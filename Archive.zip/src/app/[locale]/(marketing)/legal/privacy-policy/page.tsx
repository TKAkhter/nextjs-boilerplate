import Policy from "@/app/[locale]/(marketing)/legal/privacy-policy/PrivacyPolicy"

export default function Home() {
  return (
    <>
      <Policy />
    </>
  )
}
