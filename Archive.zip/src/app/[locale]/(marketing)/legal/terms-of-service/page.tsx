import Termm from "@/app/[locale]/(marketing)/legal/terms-of-service/terms-of-service"

export default function Home() {
  return (
    <>
      <Termm />
    </>
  )
}
