import Services from "@/app/[locale]/(marketing)/company/support/Services"

const Page = () => {
  return <Services />
}

export default Page
