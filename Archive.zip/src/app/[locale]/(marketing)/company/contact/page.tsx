import { DemoForm } from "@/app/[locale]/(marketing)/company/contact/_form"

const DemoPage = () => {
  return <DemoForm />
}

export default DemoPage
