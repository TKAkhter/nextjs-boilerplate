import About from "@/app/[locale]/(marketing)/company/about/About"

export default function Home() {
  return (
    <>
      <About />
    </>
  )
}
