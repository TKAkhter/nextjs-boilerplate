import Custommers from "@/app/[locale]/(marketing)/company/custommers/Custommers"

export default function Home() {
  // Webvital();
  return (
    <>
      <Custommers />
    </>
  )
}
