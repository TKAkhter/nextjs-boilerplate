const routeList = {
  Dashboard: {
    href: "/dashboard",
  },

  Profile: {
    href: "/profile",
  },
  Settings: {
    href: "/usersettings",
  },
}
export default routeList
